import Data.Maybe

data Tree a = Empty  | Node a (Tree a) (Tree a) deriving (Show) 

shift :: Tree a -> Tree a -> Tree a
shift Empty Empty = Empty
shift (Node a ll lr) r = Node a (shift ll lr) r
shift Empty (Node a rl rr) = Node a Empty (shift rl rr)

nodeMaybe :: (Maybe a) ->  (Tree a) ->  (Tree a) ->  (Tree a)
nodeMaybe Nothing Empty Empty = Empty
nodeMaybe (Just value) l r = Node value l r
nodeMaybe Nothing l r = shift l r

removeIf :: (a -> Bool) -> Tree a -> Tree a
removeIf f Empty = Empty
removeIf f (Node a Empty Empty) = nodeMaybe value Empty Empty
  where value = if f a
                then Nothing
                else Just a
removeIf f (Node a l r) = nodeMaybe value (removeIf f l) (removeIf f r)
  where value = if f a
                then Nothing
                else Just a

testTree = Node 1 (Node 2 (Empty) (Node 3 Empty Empty)) (Node 4 (Node 3 Empty Empty) Empty)

main = print $ removeIf odd testTree
