import Data.Maybe

data LeafTree a = Leaf a | Branch (LeafTree a) (LeafTree a) deriving (Show) 

merge :: Maybe (LeafTree a) -> Maybe (LeafTree a) -> Maybe (LeafTree a)
merge Nothing Nothing = Nothing
merge Nothing t = t  
merge t Nothing = t
merge l r = Just $ Branch (fromJust l) (fromJust r)

removeIf :: (a -> Bool) -> LeafTree a -> Maybe (LeafTree a)
removeIf f (Leaf value) = if (f value)
                        then Nothing
                        else Just (Leaf value)
removeIf f (Branch l r) = merge (removeIf f l) (removeIf f r)

testTree = (Branch (Branch (Branch (Leaf 1) (Leaf 3)) (Leaf 5)) (Leaf 3))

main = print $ removeIf odd testTree
